@extends('errors::layout')

@section('title', __('Service Unavailable'))
@section('message', __('We are currently performing maintenance. Please check back later.'))